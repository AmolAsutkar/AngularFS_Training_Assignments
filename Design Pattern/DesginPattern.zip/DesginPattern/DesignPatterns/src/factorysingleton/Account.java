package factorysingleton;

public abstract class Account {

	public abstract void withdraw(double amount);
	public abstract void deposit(double amount);
}
