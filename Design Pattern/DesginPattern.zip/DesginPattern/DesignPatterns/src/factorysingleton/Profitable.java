package factorysingleton;

public interface Profitable {

	void addInterest(int months);
}
