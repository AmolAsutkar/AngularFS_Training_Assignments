package com.citiustech.dao;

import java.util.List;

import com.citiustech.entity.Album;
import com.citiustech.entity.Song;

public class AlbumSongDao extends GenericDao{

	public List<Album> findAlbumByReleaseYear(int year){
		return entitymanagerfactory
				.createEntityManager()    // warning goes away when adding Customer.class
				.createQuery("select al from Album al where year(al.release_Date)=:rdst",Album.class)    //JPQL query is independent of database
				.setParameter("rdst", year)
				.getResultList();		
	}
	
	public List<Song> findSongsByArtist(String artist){
		return entitymanagerfactory
				.createEntityManager()    // warning goes away when adding Customer.class
				.createQuery("select s from Song s where s.artist=:ast",Song.class)    //JPQL query is independent of database
				.setParameter("ast", artist)
				.getResultList();
		
	}
	
	public List<Album> findAlbumByArtist(String artist){
		return entitymanagerfactory
				.createEntityManager()    // warning goes away when adding Customer.class
				.createQuery("select al from Album al inner join al.songs s where s.artist=:ast",Album.class)    //JPQL query is independent of database
				.setParameter("ast", artist)
				.getResultList();
		
	}
	
	public List<Song> findSongByCopyright(String copyright){
		return entitymanagerfactory
				.createEntityManager()    // warning goes away when adding Customer.class
				//.createQuery("select s from Song s where s.album.copyright=:cright",Song.class)    //JPQL query is independent of database

				.createQuery("select s from Song s inner join s.album al where al.copyright=:cright",Song.class)    //JPQL query is independent of database
				.setParameter("cright", copyright)
				.getResultList();
		
	}
	
	public List<Object[]> findAllSongsInfo(){
		return entitymanagerfactory
				.createEntityManager()    // warning goes away when adding Customer.class

				.createQuery("select s.title, s.artist, al.album_Name from Song s inner join s.album al",Object[].class)    //JPQL query is independent of database
				.getResultList();
		
	}
}
