package com.d2;

public class Address {

	private String landmark;
	private String city;
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "landmark=" + landmark + ", city=" + city + "";
	}
	
}
