package com.d4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/d4/config.xml");
		Emp emp = context.getBean("obj",Emp.class);
		System.out.println(emp);
		
		Emp emp1 = context.getBean("obj",Emp.class);
		System.out.println(emp1.hashCode());
		System.out.println(emp.hashCode());
		
		

	}

}
