package com.d5;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citiustech.PreImpactDay3SpringWithMaven.App;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/d5/config.xml");
		LoginService ls = context.getBean("ls", LoginService.class);
		boolean isValid = ls.isValidUser();
		System.out.println("Is Valid User ="+isValid);
		
	}

}
