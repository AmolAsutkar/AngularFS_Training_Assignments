package com.d1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/d1/config.xml");
		Employee emp = context.getBean("emp",Employee.class);
		System.out.println(emp.getEmp_name());
		System.out.println(emp.getProjects_name().getClass().getName());
		System.out.println(emp.getEmp_departments().getClass().getName());

	}

}
