package com.d1;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class Employee {
	private String emp_name;
	private List<String> projects_name;
	private Map<Integer,String> emp_departments;
	private Properties prop;
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public List<String> getProjects_name() {
		return projects_name;
	}
	public void setProjects_name(List<String> projects_name) {
		this.projects_name = projects_name;
	}
	public Map<Integer, String> getEmp_departments() {
		return emp_departments;
	}
	public void setEmp_departments(Map<Integer, String> emp_departments) {
		this.emp_departments = emp_departments;
	}
	public Properties getProp() {
		return prop;
	}
	public void setProp(Properties prop) {
		this.prop = prop;
	}
	@Override
	public String toString() {
		return "Employee [emp_name=" + emp_name + ", projects_name=" + projects_name + ", emp_departments="
				+ emp_departments + ", prop=" + prop + "]";
	}
	
	

}
