package com.d5;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

//@Component("ls")
@Service("ls")
public class LoginService {
	
	public boolean isValidUser() {
		if("admin".equals("admin"))
		return true;
		else
			return false;
	}

}
